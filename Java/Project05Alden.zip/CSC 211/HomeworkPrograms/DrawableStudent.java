import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Random;

public class DrawableStudent extends Student implements DrawableInterface 
{
	// Data fields
	private Point Location;
	private double xVelocity;
	private double yVelocity;
	private Color shirtColor;
	private DrawableBackpack myBackpack; // Changed from DrawableTextbook
	
	// Constant data fields
	private final int BODY_WIDTH = 150;
	private final int BODY_HEIGHT = 250;

	// Default Constructor
	public DrawableStudent()
	{
		Location 	= new Point(0,0);
		xVelocity 	= 0;
		yVelocity 	= 0;
		shirtColor 	= Color.CYAN;
		myBackpack  = new DrawableBackpack();
		
		
		//myBook 		= new DrawableTextbook(); -- disabled for project 5
	}
	
	// Parameterized constructor
	public DrawableStudent (Point p, double theXVel, double theYVel, Color theColor, DrawableBackpack theBackpack)//DrawableTextbook theBook)
	{
		Location 	= p;
		xVelocity 	= theXVel;
		yVelocity 	= theYVel;
		shirtColor 	= theColor;
		//myBook 	= theBook; -- disabled for project 5
		myBackpack 	= theBackpack;
	}
	
	
	// Methods
	
	// Accessor methods
	public DrawableBackpack getBackpack()
	{
		return myBackpack;
	}
	
	public DrawableTextbook getBook()
	{
		return myBackpack.getBooks()[new Random().nextInt(myBackpack.getBooks().length)];
	}
	
	@Override
	public int getX()
	{
		return (int)Location.getX();
	}
	
	@Override
	public int getY() 
	{
		return (int)Location.getY();
	}

	@Override
	public void moveTo(int absX, int absY) 
	{
		Location.x = absX;
		Location.y = absY;
	}

	@Override
	public void moveTo(Point whereToGo) 
	{
		//Sets the location to the point passed in the parameter
		Location = whereToGo;
	}

	@Override
	public void moveBy(int dX, int dY) 
	{
		Location.x += dX;
		Location.y += dY;
	}

	@Override
	public void move() 
	{
		Location.x += xVelocity;
		Location.y += yVelocity;
	}

	@Override
	public double getVelocityX() 
	{
		return xVelocity;
	}

	@Override
	public double getVelocityY() 
	{
		return yVelocity;
	}

	@Override
	public void setVelocity(double dvX, double dvY) 
	{
		xVelocity = dvX;
		yVelocity = dvY;
	}

	@Override
	public Color getColor() 
	{
		return shirtColor;
	}

	@Override
	public void setColor(Color theColor) 
	{
		shirtColor = theColor;
	}

	@Override
	public void draw(Graphics pen) 
	{
		// Set the color
        pen.setColor(shirtColor);
        // Body
        pen.fillRect(Location.x, Location.y, BODY_WIDTH, BODY_HEIGHT);
        
        // Left Arm
        pen.fillRect(Location.x-40, Location.y, 40, BODY_HEIGHT + 50);
        // Right Arm
        pen.fillRect(Location.x+BODY_WIDTH, Location.y, 40, BODY_HEIGHT + 50);

        // Outline arms for visibility
        pen.setColor(Color.BLACK);
        pen.drawRect(Location.x-40, Location.y, 40, BODY_HEIGHT+ 50);
        pen.drawRect(Location.x+BODY_WIDTH, Location.y, 40, BODY_HEIGHT +50 );
        
        // Pants Top
        pen.setColor(Color.DARK_GRAY);
        pen.fillRect(Location.x, Location.y +BODY_HEIGHT, 150, 100);
        // Left Leg      
        pen.fillRect(Location.x, Location.y+BODY_HEIGHT+100, 50, 200);
        // Right Leg
        pen.fillRect(Location.x+100, Location.y+BODY_HEIGHT+100, 50, 200);
        
        // Draw Head
        pen.setColor(Color.ORANGE);
        pen.fillOval(Location.x+20, Location.y-125, 110, 150);
        
        // draw the amount of books left
        pen.setColor(Color.black);
        pen.drawString("Books left: " + myBackpack.getBookCount(), Location.x + 20, Location.y+ BODY_HEIGHT / 2);
        
        
//        myBook.move();
//        myBook.draw(pen);

	}
	
	// Sets the velocity of the book to its parameterized velocity
	public DrawableTextbook tossBook(Subjects SubjectArea)
	{
		DrawableTextbook[] bookArray = myBackpack.getBooks();
		//myBook.setVelocity(myBook.getVelocityX(), 0);
		for(int i = 0; i < myBackpack.getBookCount(); i++)
		{
			if(bookArray[i] != null)
			{
				if(bookArray[i].getSubjectType().equals(SubjectArea))
					return bookArray[i];
			}
			
		}
		// If a textbook with the subject Name does not exist in the backpack, return the heaviest textbook in the bag
		return tossBook();
	}
	
	public DrawableTextbook tossBook()
	{
		return myBackpack.getHeaviest();
	}
	
}// End class