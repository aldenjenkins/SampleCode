import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.text.DecimalFormat;
import java.util.Random;

public class DrawableIgnorance implements DrawableInterface
{
	// Data Fields
	private int xPos;
	private int yPos;
	private double xVel;
	private double yVel;
	private Subjects ignoranceType;
	private Subjects theSubject(){
		int selection = new Random().nextInt(Subjects.values().length);
		return Subjects.values()[selection];
	}
	private double health;
	private Color shirtColor;
	
	// Constant data fields
	private final int BODY_WIDTH = 150;
	private final int BODY_HEIGHT = 250;
	
	
	public DrawableIgnorance()
	{
		xPos = 800;
		yPos = 150;
		xVel = 0;
		xVel = 0;
		ignoranceType = theSubject();
		health = constrain(new Random().nextDouble(), 0.0, 1.0);
		shirtColor = new Color(new Random().nextInt(Integer.MAX_VALUE));
	}
	
	public double getHealth()
	{
		return health;
	}
	
	public void getKnowledge(DrawableTextbook book)
	{
		// If the ignorant Person's ignorancetype is of the same as the textbook hitting him, do double damage
		if(ignoranceType == book.getSubjectType())
		{
			health -= (book.getWeight() / 10) * 2;
		// If not, do normal damage
		}else
			health -= book.getWeight() / 10;
	}
	
	public Subjects getIgnoranceType()
	{
		return ignoranceType;
	}
	
	@Override
	public int getX() {
		return xPos;
	}

	@Override
	public int getY() {
		return yPos;
	}

	@Override
	public void moveTo(int absX, int absY) {
		// TODO Auto-generated method stub
		xPos = absX;
		yPos = absY;
	}

	@Override
	public void moveTo(Point whereToGo) {
		// TODO Auto-generated method stub
		xPos = whereToGo.x;
		yPos = whereToGo.y;
	}

	@Override
	public void moveBy(int dX, int dY) {
		// TODO Auto-generated method stub
		xPos += dX;
		yPos += dY;
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		xPos += xVel;
		yPos += yVel;
	}

	@Override
	public double getVelocityX() {
		// TODO Auto-generated method stub
		return xVel;
	}

	@Override
	public double getVelocityY() {
		// TODO Auto-generated method stub
		return yVel;
	}

	@Override
	public void setVelocity(double dvX, double dvY) {
		// TODO Auto-generated method stub
		xVel = dvX;
		yVel = dvY;
	}

	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setColor(Color theColor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw(Graphics pen) {
		// Set the color
        pen.setColor(shirtColor);
        // Body
        pen.fillRect(xPos, yPos, BODY_WIDTH, BODY_HEIGHT);
        
        // Left Arm
        pen.fillRect(xPos-40, yPos, 40, BODY_HEIGHT + 50);
        // Right Arm
        pen.fillRect(xPos+BODY_WIDTH, yPos, 40, BODY_HEIGHT + 50);

        // Outline arms for visibility
        pen.setColor(Color.BLACK);
        pen.drawRect(xPos-40, yPos, 40, BODY_HEIGHT+ 50);
        pen.drawRect(xPos+BODY_WIDTH, yPos, 40, BODY_HEIGHT +50 );
        
        // Pants Top
        pen.setColor(Color.DARK_GRAY);
        pen.fillRect(xPos, yPos +BODY_HEIGHT, 150, 100);
        // Left Leg      
        pen.fillRect(xPos, yPos+BODY_HEIGHT+100, 50, 200);
        // Right Leg
        pen.fillRect(xPos+100, yPos+BODY_HEIGHT+100, 50, 200);
        
        // Draw Head
        pen.setColor(Color.ORANGE);
        pen.fillOval(xPos+20, yPos-125, 110, 150);
        
        pen.setColor(Color.black);
        
        // format the double to two decimal places
        DecimalFormat df = new DecimalFormat("#.00");
        pen.drawString("Health: " + df.format(health * 100)  + "%", xPos + 20, yPos + BODY_HEIGHT/2);
        pen.drawString("Ignorance: " + ignoranceType.name(), xPos + 20, yPos + BODY_HEIGHT/2 + 20 );
		
	}
	public double constrain(double num, double lowBound, double highBound)
	{
		if(num < lowBound)
		{
			num = lowBound;
		}
		else if(num > highBound)
		{
			num = highBound;
		}
		return num;
	}
	
}