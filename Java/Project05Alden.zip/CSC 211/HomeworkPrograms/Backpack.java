public class Backpack
{
	
	// Data Fields
	private final int MAX_CAPACITY = 100;
	private DrawableTextbook[] books;
	private int currentCapacity;
	private int currentBookCount;
	
	
	//Constructors
	//Default Constructor
	public Backpack()
	{
		books = new DrawableTextbook[MAX_CAPACITY];
		currentCapacity = books.length;
		currentBookCount = 0;
	}
	
	//Parameterized Constructor
	public Backpack(int initialCapacity)
	{
		books = new DrawableTextbook[initialCapacity];
		currentCapacity = books.length;
		currentBookCount = 0;
	}
	
	
	//Accessor Methods
	/**
	 * 
	 * @return the current count of books in the backpack
	 */
	public int getBookCount()
	{
		return currentBookCount;
	}
	
	public DrawableTextbook[] getBooks()
	{
		return books;
	}
	
	/**
	 * 
	 * @return the current available amount of books that can be added
	 */
	public int getAmtCanHold()
	{
		return MAX_CAPACITY - currentCapacity;
	}
	
	/**
	 * 
	 * @return the total weight added from all textbooks in the backpack
	 */
	public int getWeight()
	{
		int totalWeight = 0;
		for(DrawableTextbook t : books)
		{
			if (t!=null)
			{
				totalWeight += t.getWeight();
			}
			
		}
		return totalWeight;
	}
	
	public void setBookCount(int num)
	{
		currentBookCount = num;
	}
	
	/**
	 * 
	 * @return true if the backpack is empty and false if the backpack has atleast one textbook
	 */
	public boolean isEmpty()
	{
		boolean isItEmpty = true;
		for(int i = 0; i < books.length; i ++)
		{
			if(books[i] != null)
			{
				isItEmpty = false;
			}
		}
		return isItEmpty;
	}
	
	/**
	 * 
	 * @param book is the textbook being checked inside of the books array
	 * @return true if the book is in the array or false otherwise
	 */
	public boolean bookIsInside(DrawableTextbook book)
	{
		for (DrawableTextbook t : books)
		{
			if(t != null)
			{
				if(t.equals(book))
				{
					return true;
				}
			}
			
		}
		return false;
	}
	
	
	// Mutator Methods
	/**
	 * 
	 * @param book
	 * @try to see if a book can be added to the next-open spot
	 * @catch if the backpack is full, which results in an out of bound error
	 */
	public void addTextbook(DrawableTextbook book)
	{
		try{
			books[currentBookCount] = book;
			currentBookCount ++;
		}catch (ArrayIndexOutOfBoundsException e){
			System.out.println("The capacity of the backpack is full! You cannot add anymore books!");
		}
	}
	
	/**
	 * 
	 * @param book is the textbook to be removed from the backpack
	 */
	public void removeTextbook(DrawableTextbook book)
	{
		boolean bookRemoved = false;
		for(int i = 0; i < books.length; i ++){
			if(books[i] != null)
			{
				if(books[i].equals(book) )
				{
					books[i] = null;
					currentBookCount --;
					bookRemoved = true;
				}
			}

		}
		if(bookRemoved)
		{
			System.out.println(book + " was removed from the backpack!");	
		}
		else System.out.println(book + " was not in the backpack!");
	}
	
	/**
	 * 
	 * @purpose removes the heaviest textbook in the packback and prints the results
	 */
	public void removeHeaviest()
	{
		double heaviestWeight = 0;
		int heaviestIndex = 0;
		for(int i = 0; i < books.length; i ++)
		{
			if(books[i] != null)
			{
				if(books[i].getWeight() > heaviestWeight)
				{
					heaviestWeight = books[i].getWeight();
					currentBookCount --;
					heaviestIndex = i;
				}
			}
			
		}
		//remove the heaviest book from the backpack
		System.out.println(books[heaviestIndex] + " was removed from the backpack with a weight of: " + books[heaviestIndex].getWeight());
		books[heaviestIndex] = null;
	}
	
	/**
	 * 
	 * @purpose removes the heaviest textbook in the packback and prints the results
	 */
	public DrawableTextbook getHeaviest()
	{
		double heaviestWeight = 0;
		int heaviestIndex = 0;
		for(int i = 0; i < books.length; i ++)
		{
			if(books[i] != null)
			{
				if(books[i].getWeight() > heaviestWeight)
				{
					heaviestWeight = books[i].getWeight();
					heaviestIndex = i;
				}
			}
			
		}	
		return books[heaviestIndex];
	}
	/**
	 * 
	 * @purpose Sets each textbook in the backpack to null. effectively removing it.
	 */
	public DrawableTextbook[] dumpPack()
	{
		DrawableTextbook[] dumpedBooks = new DrawableTextbook[books.length];
		for(int i = 0; i < books.length; i++)
		{
			dumpedBooks[i] = books[i];
			books[i] = null;
		}
		return dumpedBooks;
	}
	
}