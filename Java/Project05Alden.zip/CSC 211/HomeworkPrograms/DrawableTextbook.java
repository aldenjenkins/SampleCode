import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Random;

public class DrawableTextbook extends Textbook implements DrawableInterface
{
	// Data Fields
	private Point Location;
	private double xVelocity;
	private double yVelocity;
	private Color bookColor;
	private Subjects theSubject(){
		int selection = new Random().nextInt(Subjects.values().length);
		return Subjects.values()[selection];
	}
	
	
	//Unparameterized constructor
	public DrawableTextbook()
	{
		//subject = "Object Oriented Programming";
		Location  = new Point(150, 350);
		xVelocity = 15;
		yVelocity = 0;
		bookColor = new Color(new Random().nextInt(Integer.MAX_VALUE));
		subjectArea = theSubject();
	}
	
	//Parameterized constructor
	public DrawableTextbook(String theSubject, Point p, double xVel, double yVel, Color theColor)
	{
		//subject   = theSubject;
		Location  = p;
		xVelocity = xVel;
		yVelocity = yVel;
		bookColor = theColor;
	}
	
	/*
	 * (non-Javadoc)
	 * @see DrawableInterface#getX()
	 */
	@Override
	public int getX()
	{
		return (int)Location.getX();
	}

	/*
	 * (non-Javadoc)
	 * @see DrawableInterface#getY()
	 */
	@Override
	public int getY()
	{
		return (int)Location.getY();
	}

	/*
	 * (non-Javadoc)
	 * @see DrawableInterface#moveTo(int, int)
	 */
	@Override
	public void moveTo(int absX, int absY)
	{
		Location.x = absX;
		Location.y = absY;
	}

	/**
	 * @param point where to move to 
	 */
	@Override
	public void moveTo(Point whereToGo)
	{
		Location = whereToGo;
	}

	@Override
	public void moveBy(int dX, int dY)
	{
		Location.x += dX;
		Location.y += dY;
	}

	@Override
	public void move()
	{
		Location.x += xVelocity;
		Location.y += yVelocity;
	}

	@Override
	public double getVelocityX()
	{
		return xVelocity;
	}

	@Override
	public double getVelocityY()
	{
		return yVelocity;
	}

	@Override
	public void setVelocity(double dvX, double dvY) 
	{
		xVelocity = dvX;
		yVelocity = dvY;
	}

	@Override
	public Color getColor() 
	{
		return bookColor;
	}

	@Override
	public void setColor(Color theColor) 
	{
		bookColor = theColor;
	}

	@Override
	public void draw(Graphics pen) 
	{
		//checkBounds(pen);   -- disabled for Project 5
		pen.setColor(bookColor);
		pen.fillRect(Location.x, Location.y, 50, 70);
		pen.setColor(Color.DARK_GRAY);
		pen.setFont(new Font("Monospaced", Font.BOLD, 20));
		pen.drawString(getSubjectType().name(), Location.x, Location.y + 50);
	}
	
	private String getBookInitials()
	{
		String bookSubject = getSubject();
		String initials = bookSubject.substring(0, 1);
		// For each loop which tests each char in bookSubject
		for (int i = 0; i < bookSubject.length() - 1; i++)
		{
			// if the character is a space then the next char will the the next initial
			if(bookSubject.charAt(i) == ' ')
			{
				initials += bookSubject.substring(i+1, i+2);
			}
		}
		return initials;
	}
	
	// Constrains the value num to the low bound and high bound
	public int constrain(int num, int lowBound, int highBound)
	{
		if(num < lowBound)
		{
			num = lowBound;
			xVelocity *= -1;
		}
		else if(num > highBound)
		{
			num = highBound;
			xVelocity *= -1;
		}
		return num;
	}
	
	// Constrains the x and y location of the textbook to make sure that the bounds are within the panel
//	private void checkBounds(Graphics pen)
//	{
//		Location.x = constrain(Location.x, 0, (int)pen.getClipBounds().getWidth());
//		Location.y = constrain(Location.y, 0, (int)pen.getClipBounds().getHeight());
//	}
	
}