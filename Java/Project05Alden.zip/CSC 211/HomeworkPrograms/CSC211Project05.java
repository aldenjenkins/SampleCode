import javax.swing.JFrame;

/*
 * Title:  	Individual Programming Project 2
 * Author:  Alden Jenkins
 * Date created: 10/24/2016
 */

public class CSC211Project05
{
	public static void main(String args[]) throws InterruptedException
	{

		JFrame project05Window = new JFrame();
		project05Window.setSize(1024, 800); // width x height 
	    project05Window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        project05Window.setTitle("Project 05: Let's destroy some ignorance!"); 
        
        // This is the panel for this Lab
		Project05Panel panel = new Project05Panel();
        project05Window.add(panel); 
        
        project05Window.setVisible(true); 
        
        // Launch the ball animation
        panel.fightIgnorance();
	}
}