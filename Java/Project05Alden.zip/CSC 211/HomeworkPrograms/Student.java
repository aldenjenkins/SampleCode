/**Team Quest
 * 
 * Team picon, go!
 * 
 * @author Alden Jenkins, polly zhou, dillon shoemo, nick kulungian, emmanuel oje, ihab rashid
 *
 */

public class Student
{
	// ***Data Fields***
	private String name;
	private Textbook book;
	private double health;
	private int knowledge;
	
	
	// ***Constructors***
	// Default Constructor
	public Student()
	{
		name      = "Pat Zhang-Garcia";
		book 	  = new Textbook("Object-Oriented Programming", 800);
		health 	  = 1.0;
		knowledge = 0;
	}
	
	// Parameterized Constructor
	public Student(String theName, Textbook theBook)
	{
		name 	  = theName;
		book	  = theBook;
		health 	  = 100;
		knowledge = 0;
	}
	
	
	// ***Accessor Methods***
	// Get the student's name
	public String getName()
	{
		return name;
	}
	// Get the student's Textbook
	public Textbook getTextBook()
	{
		return book;
	}
	// Get the student's health
	public double getHealth()
	{
		return health;
	}
	// Get the student's knowledge
	public int getKnowledge()
	{
		return knowledge;
	}
	
	
	// ***Mutator Methods***
	// Change the Student's name
	public void setName(String theName)
	{
		name = theName;
	}
	// Change the Student's knowledge
	public void learnSomething(int numPages)
	{
		knowledge += book.readPages(numPages);
	}
	
	
	// ***ToString Method*** tests all get functions and the textbook tostring method
	public String toString()
	{
		String theString = "Student: " + name + " has the textbook: " + book.getSubject() + 
							" and has a knowledge of: " + knowledge +
							". " + book.toString() ;
		return theString;
	}



}// End class