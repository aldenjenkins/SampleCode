import java.util.Random;

public class Textbook
{	
    // average weight of each page
    public final static double PAGE_WEIGHT = 0.0025;
    
    // amount of "knowledge" found on each page
    // knowledge is halved if book has already been read
    public final static int PAGE_KNOWLEDGE = 5;
	
	// ***Declare Data fields***
	protected String 	subject;
	private int 		pageCount;
	private int			unreadPages;
	protected Subjects 	subjectArea;
	private Subjects theSubject(){
		int selection = new Random().nextInt(Subjects.values().length);
		return Subjects.values()[selection];
	}
	
	
	// ***Create Constructors***
	// Default Constructor
	public Textbook()
	{
		subjectArea = Subjects.valueOf("PROGRAMMING");
		subject 	= "Object Oriented Programming";
		pageCount 	= new Random().nextInt(2000) + 1;
		unreadPages = pageCount;
	}
	// Constructor with a subject only
	public Textbook(Subjects theSubject)
	{
		subjectArea = theSubject;
		pageCount 	= new Random().nextInt(2000) + 1;
		unreadPages = pageCount;
	}
	
	// Parameterized contructor
	public Textbook(String theSubject, int thePageCount)
	{
		subject = theSubject;
		subjectArea = theSubject();
		pageCount 	= constrain(thePageCount, 0, 2000);
		unreadPages = thePageCount;
	}
	
	// Constructor with a subject and number of pages
	public Textbook(Subjects theSubject, int thePageCount)
	{
		subjectArea = theSubject;
		pageCount 	= constrain(thePageCount, 0, 2000);
		unreadPages = thePageCount;
	}
	
	
	// ***Accessor Methods***
	public Subjects getSubjectType()
	{
		return subjectArea;
	}
	
	// Return the Textbook's subject
	public String getSubject()
	{
		return subject;
	}
	// Return the Textbook's page count
	public int getPageCount()
	{
		return pageCount;
	}
	// Return the Textbook's unread page count
	public int getUnreadPageCount()
	{
		return unreadPages;
	}
	// Return the Textbook's weight by multiplying the number of pages by the weight of each page (0.0025kg)
	public double getWeight()
	{
		return pageCount * PAGE_WEIGHT;
	}
	
	
	
	// ***Mutator Methods***
	
	public void setSubjectArea(Subjects theSubject)
	{
		subjectArea = theSubject;
	}
	
	// Read a certain number of pages and return the knowledge gained
	public double readPages(int numPages)
	{
        // check parameter is within a valid range
        if (numPages > pageCount)
        {
            numPages = pageCount;
        }

        // return this value
        int knowledgeGained = 0; 

        if (unreadPages == 0)
        {
            // we've already read the book so this is a review
            knowledgeGained = numPages * PAGE_KNOWLEDGE / 2;
        }
        else if (unreadPages <= numPages)
        {
            // fifrst time pages are read, we gain full knowledge
            // remaining pages are only half knowledge
            knowledgeGained = unreadPages * PAGE_KNOWLEDGE + (numPages - unreadPages) * PAGE_KNOWLEDGE / 2;
            unreadPages = 0;
        }
        else
        {
           knowledgeGained = numPages * PAGE_KNOWLEDGE;
           // we need to decrement the number of pages still unread
           unreadPages -= numPages;
        }
		return knowledgeGained;
	}// End readPages
	
	//returns true if the subject and pagecount are the same for both books being compared.
	public boolean equals(Textbook book)
	{
		return( book.getSubject() == subject && book.getPageCount() == pageCount );
	}
	
	// returns 1 if compared book's weight is greater than the original,
	// returns -1 if compared book's weight is less than the original
	// returns 0 if compared book's weight is equal to the orignal's.

	
	// toString method
	public String toString()
	{
		String theString = "The Textbook: " + subject + " has a total pagecount of: " + pageCount + " and a current unread pagecount of: " + unreadPages;
		return theString;
	}
	
	// I didnt receive credit in my grade for this in our teamquest
	public int compareTo(Textbook book)
	{
		if(book.getWeight() < this.getWeight())
		{
			return 1;
		}else if(book.getWeight() > this.getWeight())
		{
			return -1;
		}else return 0;
	}
	
	public int constrain(int num, int lowBound, int highBound)
	{
		if(num < lowBound)
		{
			num = lowBound;
		}
		else if(num > highBound)
		{
			num = highBound;
		}
		return num;
	}
	
}// End class