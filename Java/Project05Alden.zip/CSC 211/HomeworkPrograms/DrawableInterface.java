import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 * @author Alden Jenkins
 * @purpose derp
 * @date_created 10/23/16
 * @category Interface
 * @version 1.fun
 */
public interface DrawableInterface
{
	/**
	 * 
	 * @return the x location of the drawable object
	 */
	public int getX();
	
	/**
	 * 
	 * @return the y location of the drawable 
	 */
	public int getY();
	
	/**
	 * 
	 * @param absX
	 * @param absY
	 * moves the drawable object to the x position absX and the y positon absY
	 */
	public void moveTo(int absX, int absY);
	
	/**
	 * 
	 * @param whereToGo
	 * moves the drawable object to the point whereToGo
	 */
	public void moveTo(Point whereToGo);
	
	/**
	 * 
	 * @param dX
	 * @param dY
	 * Moves the drawable object by dX amount in the x direction and dY amount in the y direction
	 */
	public void moveBy(int dX, int dY);
	
	/**
	 * 
	 * @purpose moves the drawable object in the x and y direction with their respective velocities
	 */
	public void move();
	
	/**
	 * 
	 * @return the velocity in the x direction for the object
	 */
	public double getVelocityX();
	
	/**
	 * 
	 * @return the velocity in the y direction for the object
	 */
	public double getVelocityY();
	
	/**
	 * 
	 * @param dvX
	 * @param dvY
	 * sets the velocity to the changes in velocity: dvX and dvY
	 */
	public void setVelocity(double dvX, double dvY);
	
	/**
	 * 
	 * @return the color of the drawable object
	 */
	public Color getColor();
	
	/**
	 * 
	 * @param theColor
	 * sets the color of the drawable object to the color theColor
	 */
	public void setColor(Color theColor);
	
	/**
	 * 
	 * @param pen
	 * draws the drawable object using the Graphics object pen
	 */
	public void draw(Graphics pen);
}