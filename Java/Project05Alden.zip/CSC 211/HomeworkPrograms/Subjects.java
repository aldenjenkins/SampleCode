/**
 * Enumerated type for the textbook subjectArea 
 * and Ignorance creature's type
 */
public enum Subjects 
{
    PROGRAMMING, ALGORITHMS, AI, OPSYS, INFOSEC,
    ENGLISH, SPANISH, CHINESE, HINDI,
    PHYSICS, CHEMISTRY, BIOLOGY,
    PSYCHOLOGY, HISTORY, MARKETING,
    CALCULUS, ALGEBRA, DISCRETE
}
