import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Random;

public class DrawableBackpack extends Backpack implements DrawableInterface
{
	// Data Fields
	private int xPos;
	private int yPos;
	private double xVel;
	private double yVel;
	private Color color;
	
	// Constructors
	
	public DrawableBackpack()
	{
		xPos = 0;
		yPos = 0;
		xVel = 5;
		yVel = 5;
		color = new Color(new Random().nextInt(Integer.MAX_VALUE));
	}
	
	public DrawableBackpack(int theXPos, int theYPos, double theXVel, double theYVel, Color theColor)
	{
		xPos = theXPos;
		yPos = theYPos;
		xVel = theXVel;
		yVel = theYVel;
		color = theColor;
	}
	
	// Methods
	
	
	@Override
	public int getX() 
	{
		return xPos;
	}

	@Override
	public int getY() 
	{
		return yPos;
	}

	
	@Override
	public void moveTo(int absX, int absY) 
	{
		xPos = absX;
		yPos = absY;
	}

	@Override
	public void moveTo(Point whereToGo) 
	{
		xPos = whereToGo.x;
		yPos = whereToGo.y;
	}

	@Override
	public void moveBy(int dX, int dY) 
	{
		xPos += dX;
		yPos += dY;
	}

	@Override
	public void move() 
	{
		xPos += xVel;
		yPos += yVel;
	}

	@Override
	public double getVelocityX() 
	{
		return xVel;
	}

	@Override
	public double getVelocityY() 
	{
		return yVel;
	}

	@Override
	public void setVelocity(double dvX, double dvY) 
	{
		xVel = dvX;
		yVel = dvY;
	}

	@Override
	public Color getColor() 
	{
		return color;
	}

	@Override
	public void setColor(Color theColor) 
	{
		color = theColor;
	}

	@Override
	public void draw(Graphics pen) 
	{
		checkBounds(pen);
		pen.setColor(color);
		pen.fillRect(xPos, yPos, 200, 70);
		//pen.setColor(Color.DARK_GRAY);
		//pen.setFont(new Font("Monospaced", Font.BOLD, 20));
		//pen.drawString(getBookInitials(), xPos, yPos + 50);
	}
	
	// Constrains the value num to the low bound and high bound
	public int constrain(int num, int lowBound, int highBound)
	{
		if(num < lowBound)
		{
			num = lowBound;
			
		}
		else if(num > highBound)
		{
			num = highBound;
			
		}
		return num;
	}
	
	// Constrains the x and y location of the textbook to make sure that the bounds are within the panel
	private void checkBounds(Graphics pen)
	{
		xPos = constrain(xPos, 0, (int)pen.getClipBounds().getWidth());
		yPos = constrain(yPos, 0, (int)pen.getClipBounds().getHeight());
	}
	
}