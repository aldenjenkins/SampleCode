import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Point;
import java.util.Random;

/*
 * Title: Project 05 Panel
 * Author: Alden Jenkins
 * Purpose: the driver class for CSC211 Project 5
 * Date Due: 12/8/16
 * Comments: 	
 * 			1) Textbooks not having more than 2000 pages occurs in the DrawableTextbook's constructor method
 * 			2) subjectArea randomness occurs in the DrawableTextbook's constructor as well
 * 
 */


public class Project05Panel extends JPanel
{

	// Data Fields
	private DrawableTextbook textbook1;
	private DrawableStudent student1;
	private DrawableIgnorance ignorance1;
	private DrawableBackpack backpack1;
	private int ignorancesVanquished;
	
	// default only constructor
	Project05Panel()
	{
		backpack1 = new DrawableBackpack(20, 90, 0, 0, new Color(new Random().nextInt(Integer.MAX_VALUE)));
		// Add 50 textbooks per specifications of Project 5
		for(int i = 0; i < 50; i++)
		{
			backpack1.addTextbook(new DrawableTextbook()); // Add a new drawable textbook with a random subject from the enums file
		}
		student1 = new DrawableStudent(new Point(50, 150), 0, 0, Color.BLUE, backpack1);
		ignorance1 = new DrawableIgnorance();
		ignorancesVanquished = 0;
	}

	public void paintComponent(Graphics pen)
	{
		// Draw each object
		backpack1.draw(pen);
        student1.draw(pen);
        ignorance1.draw(pen);
        if(textbook1 != null){
        	textbook1.draw(pen);
        }
        
        pen.drawString("Ignorance Monsters Vanquished: " + Integer.toString(ignorancesVanquished), 400, 20);
        
	}
	
	public void fightIgnorance() throws InterruptedException
	{
		// Asks the user for a binary input selection to determine whether to use the heaviest book or the one matching the ignorance's ingorance type
		JOptionPane HeavyOrSubject = new JOptionPane();
		int reply = JOptionPane.showConfirmDialog(null, "Enter yes to shoot a book matching the Monster's ignorance type and no to throw the heaviest in the backpack.", "Select your weapon", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
        	textbook1 = student1.tossBook(ignorance1.getIgnoranceType());
        }
        else {
        	textbook1 = student1.tossBook();
        }
	
		// While the student still has textbooks to be thrown
		while( !student1.getBackpack().isEmpty())
		{
		   // move the textbook
	       textbook1.move();
	       
	       // Check if the textbook has overlapped the ignorance monster
	       if(textbook1.getX() >= ignorance1.getX())
	       {
	    	   ignorance1.getKnowledge(textbook1);
	    	   // Check if the ignorance monster still has health, if not, replace the monster with a new one 
		       if(ignorance1.getHealth() <= 0)
		       {
		    	  ignorance1 = new DrawableIgnorance(); 
		    	  ignorancesVanquished ++;
		       }
		       // Remove the textbook from the backpack
	    	   student1.getBackpack().removeTextbook(textbook1);
	    	   
	    	   // Set the textbook to heaviest or subject-based according to the user's previous input
	           if (reply == JOptionPane.YES_OPTION) {
	        	   textbook1 = student1.tossBook(ignorance1.getIgnoranceType());
	           }
	           else {
	        	   textbook1 = student1.tossBook();
	           }
	       }
	       
	      
           // force redraw of window to draw balls in new locations
           // ** repaint calls paintComponent
           repaint(); 
           
           // sleep for 10 milliseconds so the animation doesn't pass too fast
           Thread.sleep(10);
		}
	}
	
	
	//-- Disabled for project 5 ---
	
//	public void shootBook() throws InterruptedException
//    {
//		//
//		student1.tossBook();
//		// Mark the current time to put it's value in memory
//		double curTime = System.currentTimeMillis();
//		// While the current time minus the initial time is less than 20 seconds
//		while( System.currentTimeMillis() - curTime  < 20000)
//		{
//		   // move the textbook
//	       textbook1.move();
//			
//           // force redraw of window to draw balls in new locations
//           // ** repaint calls paintComponent
//           repaint(); 
//           
//           // sleep for 10 milliseconds so the animation doesn't pass too fast
//           Thread.sleep(10);
//		}
//       
//    }
	
}