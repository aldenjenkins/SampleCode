<?php
include "core/init.php";
protect_page();
adminprotect_page();

if(empty($_POST) === false){
	$required_fields = array('newName', 'newCategory', 'newBusinessName');

	foreach($_POST as $key=>$value){
		if(empty($value) && in_array($key, $required_fields) === true){
			$errors[] = 'All fields are required';
			break 1;
		}
	}
	if(empty($errors) === true){
		if(array_was_sanitized(array($_POST['newName'], $_POST['newCategory'], $_POST['newBusinessName']))){
			$errors[] = "You must enter valid characters!";
		}		
	}
}


iF(empty($_POST) === false && empty($errors) === true){
	 $newuser = array(
		'newName' => $_POST['newName'],
		'newCategory' => $_POST['newCategory'],
		'newBusinessName'  => $_POST['newBusinessName'],
	);
		
	add_user($newuser);
	header('Location: admincontrolpanel.php?success');
	exit();
}
include 'includes/admincontrolpanelcontent.php';