
<html>
<head>
<title>Admin Control Panel</title>
<link rel="stylesheet" href="css/indexstyle.css">
</head>
	<body>
		<header>
		<h3>
				Logged in as: <?php echo $user_data['username'] . " (" . $user_data['first_name'] . " " . $user_data['last_name'] . ")";?> <a href = "logout.php"> Logout</a>
			</h3>
			<h2>Remove Refer-ee</h2>
			<?php 
			include "widgets/returntoadmincontrolpage.php";
			echo "<h3><a href=\"referrals.php\">Click Here</a> to submit a referral</h3>";
			
			if(!(isset($_GET['success']) && empty($_GET['success']))){
				$result = mysqli_query(mysqli_connect('localhost', 'root', 'mysql', 'Chamber'), "SELECT * FROM `members`");
				?>
		</header>
		
		<!-- ------------------------------------------- -->
		<form method="post" action="removeuser.php">
			<div>
				<article>
					<table>
					<caption>Remove a Member</caption>
						<tr>
							<th>Name of Member | Category | Name of Business</th>
						</tr>
						<tr>
							<td>
								<select name = "usertoDelete">					
									<option value ="none" selected="selected"></option>
									<?php 
										while($row = mysqli_fetch_array($result))
										{
											$string = '<option value="' . $row['id'] . '" ' . '">'.$row['Name'] . " | ". $row['Category'] . " | " . $row['BusinessName']. "</option>"; 
											echo($string);
										}
										?>
								</select>
							</td>
						</tr>
					</table>
					<input type="submit"  value="Submit">
				</article>
			</div>
		</form>
	</body>
</html>
<?php 
} else{
	echo "<h3>User Deleted!";
	include "includes/widgets/returntoremoveuser.php";
	echo "</h3></header>";
}
?>