<html>
	<head>
		<title>Admin Control Panel</title>
		<link rel="stylesheet" href="css/indexstyle.css">
	</head>

	<body>
		<header>
			<h3>
				Logged in as: <?php echo $user_data['username'] . " (" . $user_data['first_name'] . " " . $user_data['last_name'] . ")";?> <a href = "logout.php"> Logout</a>
			</h3>
			<h2>Add new Referral-ee</h2>
			
			<?php include "includes/widgets/returntoremoveuser.php";
			if(!(isset($_GET['success']) && empty($_GET['success']))){
			?>
			
			<?php include "widgets/returntoreferrals.php";
			    if(!empty($errors))
				echo "<h3>" . output_errors($errors) . "</h3>";		
			?>
		</header>
		
		<!-- ------------------------------------------- -->
		<form method="post" action="admincontrolpanel.php">
			<div>
				<article>
					<table>
					<caption>Add a new Member</caption>
						<tr>
							<th>Name (First and last)</th>
							<th>Category</th>
							<th>Business Name</th>
						</tr>
						<tr>
							<td><input type="text" name = "newName" maxlength="33"></td>
							<td><input type="text" name = "newCategory" maxlength="33"></td>
							<td><input type="text" name = "newBusinessName" maxlength="33"></td>
						</tr>
					</table>
					<input type="submit"  value="Submit">
				</article>
			</div>
		</form>
	</body>
</html>
<?php 
} else{
	echo "<h3>User created! <br><a href = \"admincontrolpanel.php\">Click Here</a> to add another user or... <br> <a href =  \"referrals.php\"> Click Here</a> to return to the referrals page.</h3><header>";
}
?>