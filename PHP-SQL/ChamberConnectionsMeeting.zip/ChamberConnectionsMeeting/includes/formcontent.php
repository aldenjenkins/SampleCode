

<html>
	<head>
		<title>Chamber Connections Signup</title>
		<link rel="stylesheet" href="css/indexstyle.css">
	</head>
	<BODY>	
		<header>
			
			<h3>
				Logged in as: <?php echo $user_data['username'] . " (" . $user_data['first_name'] . " " . $user_data['last_name'] . ")";?> <a href = "logout.php"> Logout</a>
			</h3>
			<?php
			if(empty($errors)){
			echo "<h2>" . 'You have submitted ' . get_num_referrals($user_data['first_name'] . " " . $user_data['last_name']) . ' Referral forms so far.' . "</h2>";
			if($user_data['user_id'] == 1){
				echo "<a href = admincontrolpanel.php>Click here</a> to Access the admin control panel";
			}
			if(!(isset($_GET['success']) && empty($_GET['success']))){
				$result = mysqli_query(mysqli_connect('localhost', 'root', 'mysql', 'Chamber'), "SELECT * FROM `members`");
				$result2 = mysqli_query(mysqli_connect('localhost', 'root', 'mysql', 'Chamber'), "SELECT * FROM `members`");
				 
			?>
			<h1>
				Referrals ~ Closed Business ~ Outside Meetings
			</h1>
		</header>
	<!----------------------------------------------------------->
		<form method="post" action="referrals.php">
			<div>
				<article class = "MemberSelection">
				<h3>Member Receiving Referral</h3>
					<table class = "referral">
						<tr>
							<th>Name of Member | Category | Name of Business</th>
						</tr>
						<tr>
							<td>
								<select name = "ReferralSelection">
									<option value ="none" selected="selected"></option>
										<?php 
										while($row = mysqli_fetch_array($result))
										{
											$string = '<option value="' . $row['Name'] . ' ' . '"' . '">'.$row['Name'] . " | ". $row['Category'] . " | " . $row['BusinessName']. "</option>"; 
											echo($string);	
										}
										?>
								</select>
							</td>			
						</tr>
					</table>
				</article>
				<hr>
				<article class = "Referral Contact Information">
					<h3>Referral Contact Information</h3>
						<table class = "ContactInfo">
							<tr>
								<td>First Name</td>
								<td><input type="text" name="firstname"></td>
								
								<td>Last Name</td>
								<td><input type="text" name="lastname"></td>
							</tr>
							<tr>
								<td>Name of Business</td>
								<td><input type="text" name="nameofbusiness"></td>
							</tr>
							<tr>
								<td>Address</td>
								<td><input type="text" name="address"></td>
							</tr>
							<tr>
								<td>Primary Phone #</td>
								<td><input type="text" name="primaryphone" ></td>
								<td>Secondary Phone # (Optional)</td>
								<td><input type="text" name="secondaryphone" placeholder="Leave blank if same"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input type="text" name="email"></td>
							</tr>
						</table>
					<h3>Referral Details</h3>
					<textarea name = "referraldetails" rows="10" cols="100" maxlength="500" style = "resize:none;"></textarea>
				</article>	
				<hr>
				<article class = "Donation">
					<h3>Member Being Thanked</h3>
					<table class = "contribution">
						<tr>
							<th>Name of Member | Category | Name of Business</th>
							<th>$ Contribution Amount</th>
						</tr>
						
						<tr>
							<td>
								<select name = "DonationSelection">
								<option value ="none" selected="selected"></option>
									<?php 
									while($donationrow = mysqli_fetch_array($result2))
									{
										$donationstring = '<option value="' . $donationrow['Name'] . '" ' . '">'.$donationrow['Name'] . " | ". $donationrow['Category'] . " | " . $donationrow['BusinessName']. "</option>"; 
										echo($donationstring);
									}
									?>
								</select>
							</td>		
							<td>
								<input type =number name = 'ContributionAmount' maxlength = '6'>
							</td>	
						</tr>
						
					</table>
				</article>
				<hr>
				<article class = "OutsideMeetings">
					<h3>Outside Meetings</h3>
					<p>Date of Meeting <input class = "meeting" type ="date" name = "OutsideMeetingDate" placeholder = "Select Date"> Person's name <input class = "meeting" type ="text" name = "PersonsName" placeholder = "Person's Name"> 
					met with
					<input class = "meeting" type ="text" name = "MetWith" placeholder = "Person's Name">
					</p>
				</article>
				<article class = "submit">
					<input type="submit"  value="Submit">
				</article>
			</div>
		</form>
	</BODY>
</html>
<?php
			}
			
else{
	?>
		<br>
		<?php
	echo "<h2>" . 'You\'ve successfully submitted this referral information!' . "<h3>";
	?>
	<br>
	<?php
	include 'includes/widgets/returntoreferrals.php';
	
}
}elseif (empty($errors) === false){
				echo "<h2>" . 'Referral Failed:';
				echo output_errors($errors) . "</h2>";
				include 'includes/widgets/returntoreferrals.php';
			}
?>
