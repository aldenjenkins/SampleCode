<p><a href="loginpage.php">Click Here</a> to Return to the Login Page!</p>
