<?php
include 'core/init.php';
protect_page();
$num_referrals = get_num_referrals($user_data['first_name'] . ' ' . $user_data['last_name']);
echo $num_referrals;
?>
<html>
	<head>
		<title>View Your Referrals</title>
		<link rel="stylesheet" href="css/viewreferralsstyle.css">
	</head>
	<body>
		<article>
			<ul></ul>
		</article>
	</body>
</html>
