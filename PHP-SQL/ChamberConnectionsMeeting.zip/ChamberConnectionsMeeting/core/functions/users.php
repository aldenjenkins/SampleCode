<?php

/**function recover(%mode, %email){
	
	$mode      = sanitize($mode);
	$email     = sanitize($email);
	
	$user_data = user_data(user_id_from_email($email), 'first name', 'username');
	
	if ($mode == 'username'){
		email($email, 'Your username', "Hello " . $user_data ['first_name'] . ", \n\nYou need to activate your account, so use the link below:\n\nhttp://localhost:8888/Chamber%20Connections%20Meeting/activate.php?email=" . $register_data ['email'] . "&email_code=" . $register_data ['email_code'] . "\n\n-info@ChamberConnectionsReferrals.org" );)
	}
}**/


function mysqli_result($res, $row, $field=0) {
	$res->data_seek($row);
	$datarow = $res->fetch_array();
	return $datarow[$field];
}
function array_was_sanitized($array){
	//declare new array
	$sanitized_array = [];
	//for each value in $array, sanitize it and add that outcome to $sanitized_array at the same index
	$i = 0;
	foreach($array as $value){
		$sanitized_array[] = sanitize($array[$i]);
		$i ++;
	}
		
	if($sanitized_array == $array){
		return false;
	}
	else {
		return true;
	}
}

function remove_user($delete_id){
	$link = mysqli_connect('localhost', 'root', 'mysql', 'Chamber');
	$query = "DELETE FROM `members` WHERE `id` = '$delete_id'";
	mysqli_query($link, $query);

}

function add_user($newuser){
	$link = mysqli_connect('localhost', 'root', 'mysql', 'Chamber');
	array_walk ( $newuser, 'array_sanitize' );
	$data = '\'' . implode ( '\', \'', $newuser ) . '\'';
	$query = "INSERT INTO `members` (`Name`, `Category`, `BusinessName`) VALUES ($data)";
	mysqli_query($link, $query);
	
}
function get_num_referrals($submittername){
	$link = mysqli_connect('localhost', 'root', 'mysql', 'Chamber');
	$query = mysqli_query($link , "SELECT COUNT(`SubmitterName`) FROM `referrals` WHERE `SubmitterName` = '$submittername'");
	$result = mysqli_result($query, 0);
	return 	$result;
}

function update_user($update_data) {
	global $session_user_id;
	$update = array ();
	array_walk ( $update_data, 'array_sanitize' );
	
	foreach ( $update_data as $field => $data ) {
		$update [] = '`' . $field . '` = \'' . $data . '\'';
	}
	
	mysql_query ( "UPDATE `users` SET " . implode ( ', ', $update ) . " WHERE `user_id` = $session_user_id" );
}
function activate($email, $email_code) {
	$link = mysqli_connect('localhost', 'root', 'mysql', 'Chamber');
	$email = mysqli_real_escape_string ($link, $email );
	$email_code = mysqli_real_escape_string ($link, $email_code );
	
	if (mysqli_result ( mysqli_query ($link, "SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$email' AND `email_code` = '$email_code' AND `active` = 0" ), 0 ) == 1) {
		mysqli_query ($link, "UPDATE `users` SET `active` = 1 WHERE `email` = '$email'" );
		return true;
	} else {
		return false;
	}
}
function change_password($user_id, $password) {
	$user_id = ( int ) $user_id;
	$password = md5 ( $password );
	
	mysql_query ( "UPDATE `users` SET `password` = '$password' WHERE `user_id` = $user_id" );
}
function register_user($register_data) {
	array_walk ( $register_data, 'array_sanitize' );
	$register_data ['password'] = md5 ( $register_data ['password'] );
	
	$fields = '`' . implode ( '`, `', array_keys ( $register_data ) ) . '`';
	
	$data = '\'' . implode ( '\', \'', $register_data ) . '\'';
	
	mysqli_query ( mysqli_connect ( 'localhost', 'root', 'mysql', 'Chamber' ), "INSERT INTO `users` ($fields) VALUES ($data)" );
	email ( $register_data ['email'], 'Activate your account', "Hello " . $register_data ['first_name'] . ", \n\nYou need to activate your account, so use the link below:\n\nhttp://localhost:8888/Alden/Chamber%20Connections%20Meeting/activate.php?email=" . $register_data ['email'] . "&email_code=" . $register_data ['email_code'] . "\n\n-info@chamberconnectionsreferrals.org" );
}

function refer($refer_data) {
	array_walk ( $refer_data, 'array_sanitize' );

	$fields = '`' . implode ( '`, `', array_keys ( $refer_data ) ) . '`';

	$data = '\'' . implode ( '\', \'', $refer_data ) . '\'';

	mysqli_query ( mysqli_connect ( 'localhost', 'root', 'mysql', 'Chamber' ), "INSERT INTO `referrals` ($fields) VALUES ($data)" );
}

function user_count() {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber') or die ("Error ". mysqli_error($link));
	return mysql_result ( mysqli_query (  "SELECT COUNT(`user_id`) FROM `users` WHERE `active` = 1" or die ("Error in the consult.." . mysqli_error($link))), 0 );
}

/**
 * user
 * @param unknown $user_id - self explanatory
 * @return sql query result from the 'users' table
 */
function user_data($user_id) {
	
		$link = mysqli_connect ( 'localhost', 'root', 'mysql', 'Chamber' ) or die ( "Error " . mysqli_error ( $link ) );
		$data = [];
		
		// set user id
		$user_id = ( int ) $user_id;
		
		$func_num_args = func_num_args ();
		$func_get_args = func_get_args ();
		
		if ($func_num_args > 1) {
			unset ( $func_get_args [0] );
			
			$fields = '`' . implode ( '`, `', $func_get_args ) . '`';
			$test = mysqli_query ( $link, "SELECT $fields FROM `users` WHERE `user_id` = $user_id" );
			$data = mysqli_fetch_assoc ( $test );
			
			return $data;
		}
	 
}
function logged_in() {
	return (isset ( $_SESSION ['user_id'] )) ? true : false ;
}
function user_exists($username) {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber');
	$username = sanitize ( $username );
	$query1 = "SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username'";
	$query = mysqli_query ($link, $query1);
	$test = (mysqli_result( $query, 0 ) == 1) ? true : false;
	return $test;
}
function email_exists($email) {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber') or die ("Error ". mysqli_error($link));
	$email = sanitize ( $email );
	return (mysqli_result ( mysqli_query ($link, "SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$email'" ), 0 ) == 1) ? true : false;
}
function user_active($username) {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber') or die ("Error ". mysqli_error($link));
	$username = sanitize ( $username );
	$query = mysqli_query ( $link, "SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username' AND `active` = 1" );
	return (mysqli_result( $query, 0 ) == 1) ? true : false;
}
function user_id_from_username($username) {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber') or die ("Error ". mysqli_error($link));
	$username = sanitize ( $username );
	$test = mysqli_result( mysqli_query ( $link, "SELECT `user_id` FROM `users` WHERE `username` = '$username'" ), 0, 'user_id');
	return $test;
}
function login($username, $password) {
	$link = mysqli_connect ( 'localhost', 'root', 'mysql' , 'Chamber') or die ("Error ". mysqli_error($link));
	$user_id = user_id_from_username ( $username );
	
	$username = sanitize ( $username );
	$password = md5 ( $password );
	$test =  (mysqli_result( mysqli_query( $link, "SELECT COUNT(`user_id`) FROM `users` WHERE `username` = '$username' AND `password` = '$password'") , 0 ) == 1) ? $user_id : false;
	return $test;
}
?>