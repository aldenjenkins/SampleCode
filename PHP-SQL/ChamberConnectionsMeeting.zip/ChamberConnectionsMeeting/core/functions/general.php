<?php
function email($to, $subject, $body) {
	mail ( $to, $subject, $body, 'From: info@ChamberConnectionsReferrals.org' );
}
function logged_in_redirect() {
	if (logged_in () === true) {
		header ( 'Location: referrals.php' );
		exit ();
	}
}
function array_sanitize(&$item) {
	$item = htmlentities(strip_tags(mysqli_real_escape_string (mysqli_connect('localhost', 'root', 'mysql', 'Chamber'), $item )));
	
}
function sanitize($data) {
	return htmlentities(strip_tags(mysqli_real_escape_string (mysqli_connect('localhost', 'root', 'mysql', 'Chamber'), $data )));
}
function output_errors($errors) {
	return '<ul><li>' . implode ( '</li><li>', $errors ) . '</li></ul>';
}
function protect_page() {
	if (logged_in () === false) {
		header ( 'Location: loginpage.php' );
		echo 'You must be logged in to view this page!';
	}
}
function adminprotect_page() {
	if($_SESSION['user_id'] != 1) {
		header ( 'Location: loginpage.php' );
		echo 'You must be an admin to view this page!';
	}
}

?>