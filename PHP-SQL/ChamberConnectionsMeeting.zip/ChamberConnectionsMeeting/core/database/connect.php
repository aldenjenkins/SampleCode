<?php
$connect_error = 'Sorry, we\'re experiencing connection problems.';
$conn = mysqli_connect ( 'localhost', 'root', 'mysql' );
$conn or die ( $connect_error );
mysqli_select_db ( $conn,'Chamber' ) or die ( $connect_error );

?>