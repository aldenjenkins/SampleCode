<?php
include "core/init.php";
protect_page();
adminprotect_page();

if(empty($_POST) === false){
	$required_fields = array('newName', 'newCategory', 'newBusinessName');

	foreach($_POST as $key=>$value){
		if(empty($value) && in_array($key, $required_fields) === true){
			$errors[] = 'You must select a member to remove';
			break 1;
		}
	}
}
if(empty($_POST) === false && empty($errors) === true){
	$removeid = $_POST['usertoDelete'];
	remove_user($removeid);
	header('Location: removeuser.php?success');
	exit();
}
include 'includes/removeusercontent.php';