<?php



include 'core/init.php';


?>

<!doctype html>
<html>
<head>
<title>Alcohol</title>
 
<link rel="stylesheet" type="text/css" href="lifestyle.css">
<meta name="viewport" content="width=device-width">
  <link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="icon" type="image/x-icon" href="images/patriot.jpeg">
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css' href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/css/style.css">
</head>

<script type="text/javascript" src="js/modernizr.custom.86080.js"></script>

    <body id="page">
        <ul class="cb-slideshow">
            <li><span>Image 01</span><div><h3>I Will not Quit</h3></div></li>
            <li><span>Image 02</span><div><h3>I Will not Yield</h3></div></li>
            <li><span>Image 03</span><div><h3>I Will not Fail</h3></div></li>
            <li><span>Image 04</span><div><h3>I Will not Quit</h3></div></li>
            <li><span>Image 05</span><div><h3>I Will not Yield</h3></div></li>
            <li><span>Image 06</span><div><h3>I Will not Fail</h3></div></li>
        </ul>
        
    </body>

<body>
<?php include 'includes/userheader.php';?>
        <header>

	<img src="images/turf.png">
	
</header>
	
		<?php include 'includes/nav.php';?>
		<?php if(logged_in()=== false){
				 include 'includes/loginnav.php';
			}
			?>
		<?php include 'includes/marquee.php';?>
		
<article class="description">
<p>Here, you can find information on the detriment of Alcohol in the body.</p>

</article>



<?php 

include 'alcoslide.php';
?>
<article class="links">
<p><a href = "magnesium.php">Click Here</a> to learn more about the importance of Magnesium!</p>
<p><a href = "hydration.php">Click Here</a> to learn more about the importance of staying Hydrated!</p>
<p><a href = "marijuana.php">Click Here</a> to learn more about the detriment of Marijuana in your body!</p>
<p><a href = "sleep.php">Click Here</a> to learn more about the importance of sleep!</p>
<p><a href = "recipes.php">Click Here</a> for some great, healthy recipes!</p>
</article>
</body>
</html>