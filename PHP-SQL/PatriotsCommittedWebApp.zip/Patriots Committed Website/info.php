<!doctype html>
<html>
<?php 
//phpinfo();
include 'core/init.php';
?>


	
<head>
<title>Information</title>
<link rel="stylesheet" type="text/css" href="infostyle.css">
<link rel="icon" type="image/x-icon" href="images/patriot.jpeg">
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css' href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/css/style.css">
</head>
	
	<script type="text/javascript" src="js/modernizr.custom.86080.js"></script>

	<body id="page">
        <ul class="cb-slideshow">
            <li><span>Image 01</span><div><h3>Alden Jenkins</h3></div></li>
            <li><span>Image 02</span><div><h3>Natalie Yaw</h3></div></li>
            <li><span>Image 03</span><div><h3>Sean Lewis</h3></div></li>
            <li><span>Image 04</span><div><h3>Paige Colman</h3></div></li>
            <li><span>Image 05</span><div><h3>Abby Cousens</h3></div></li>
            <li><span>Image 06</span><div><h3>Chris Costa</h3></div></li>
            <li><span>Image 07</span><div><h3>Isabel Hamilton</h3></div></li>
            <li><span>Image 08</span><div><h3>Kyle Mcgowan</h3></div></li>
        </ul>
        
    </body>
	 
	 <body>

		
		<?php include 'includes/userheader.php';?>
		
		<?php include 'includes/infoheader.php';?>
		<?php include 'includes/nav.php';?>
		<?php if(!logged_in()===true){
				 include 'includes/loginnav.php';
			}
			?>
		<?php include 'includes/marquee.php';?>





<ul>
<p>Here you can find information about what it means to be patriots committed, and the current Governing Ordinance of Patriots Committed.</p>
</ul>
<hr>

<article>
<p>
        Patriots Committed is not a club - it's a lifestyle that raises the bar of excellence for both the athlete and the non-athlete.  It asks PHS students to commit to a 100% drug and alcohol free lifestyle, and it provides scientific rationale for all things related to optimal performance.  Patriots Committed is every bit as much about character and not only committing to one's own excellence, but to one's team, school, and town. 
</p>

<p>
Patriots Committed is currently made up of 35 student leaders, 8 of whom are apart of the governing ordinance which pass legislature for fundraisers and the ideas for expanding the organization. 
</p>
<p>
This Governing Ordinance of Ultimate Student Achievement (GO USA) was formed as a student-run organization after being invited to the Lake Placid Winter Olympic Training Center this past Summer to learn about the science behind sleep, nutrion, social drug use, training, and teamwork. Our goals in Lake Placid were to learn as much information as possible so that we could reiterate the information to everyone on our respective sport team. GO USA is compromised of one student-athlete / captain from almost every sport team at Portsmouth High School.
</p>
		</article>
		<hr>
		<table class="center" border = 1>
			<caption>Current Patriots Committed Governing Ordinance</caption>
			<tr>
				<th>Name</th>
				<th>Position</th>
				<th>Activities</th>
			</tr>
			<tr>
				<td class="coordinator"><a class ="coordinator" href="">Mrs. Larson</a></td>
				<td>Co-coordinator</td>
				<td>Assistant Principal</td>
			</tr>
			<tr>
				<td class="coordinator"><a class ="coordinator" href="">Mr. Trezvant</a></td>
				<td>Co-coordinator</td>
				<td>Athletic Director</td>
			</tr>
			<tr>
				<td class ="adult"><a class= "adult" href="">Mr. Denard</a></td>
				<td>Adult Advisor</td>
				<td>Swim team coach, Track/XC Coach</td>
			</tr>
			<tr>
				<td class ="adult"><a class= "adult" href="">Mr. Rose</a></td>
				<td>Adult Advisor</td>
				<td>Track/XC Coach</td>
			</tr>
			<tr>
				<td class ="adult"><a class= "adult" href="">Ms. Zabel</a></td>
				<td>Adult Advisor</td>
				<td>Girl's Volleyball Coach</td>
				</tr>
				<tr>
				<td class ="adult"><a class= "adult" href="">Ms. McCarthy</a></td>
				<td>Adult Advisor</td>
				<td>Girl's Lacrosse Coach</td>
			</tr>
			<tr>
				<td class = "senior"><a class ="senior" href="">Natalie Yaw</a></td>
				<td>Senior Leader</td>
				<td>Soccer, Track</td>
			</tr>
			<tr>
				<td class = "senior"><a class ="senior" href="profile.php?username=alden">Alden Jenkins</a></td>
				<td>Senior Leader</td>
				<td>Football, Model UN, Mock Trial, Student Council, Science Olympiad, <br>Men's Club Volleyball creator</td>
			</tr>
			<tr>
				<td class = "senior"><a class ="senior" href="">Abby Cousens</a></td>
				<td>Senior Leader</td>
				<td>Track & Field</td>
			</tr>
			<tr>
				<td class = "senior"><a class ="senior" href="profile.php?username=lewissean63">Sean Lewis</td>
				<td>Senior Leader</td>
				<td>Basketball</td>
			</tr>
			<tr>
				<td class = "senior"><a class ="senior" href="">Paige Coleman</td>
				<td>Senior Leader</td>
				<td>Tennis, Gymnastics, Student Council</td>
			</tr>
			<tr>
				<td class ="junior"><a class ="junior" href="">Isabelle Hamilton</td>
				<td>Junior Leader</td>
				<td>Volleyball</td>
			</tr>
			<tr>
				<td class ="junior"><a class ="junior" href="">Chris Costa</td>
				<td>Junior Leader</td>
				<td>Soccer</td>
			</tr>
			<tr>
				<td class="sophomore"><a class ="sophomore" href="">Kyle Mcgowan</td>
				<td>Sophomore Leader</td>
				<td>Hockey, Student Council</td>
			</tr>
		</table>

		<hr>

				<footer>
		<p>*Hosting Donated by Friends of the Portsmouth Prevention Coalition*</p>
		</footer>
		<!-- <h2><a href="8-login-form/index.php">Click Here to Login</a></h2> -->
	</body>
</html>