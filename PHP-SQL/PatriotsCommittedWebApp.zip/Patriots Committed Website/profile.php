<!doctype html>
<head>
	<link rel="stylesheet" type="text/css" href="protectedstyle.css">
	<link rel="icon" type="image/x-icon" href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/images/patriot.jpeg">
	<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css' >
</head>
<?php
include'core/init.php';

?>

	

	
	 <body>


		<?php include 'includes/userheader.php';?>
		
		<?php include 'includes/header.php';?>
		<?php include 'includes/nav.php';?>
		<?php if(!logged_in()===true){
				 include 'includes/loginnav.php';
			}
			?>
		<?php include 'includes/marquee.php';?>
<?php 
if(isset($_GET['username']) != true && empty($_GET['username']) != false){
	
	header('Location: index.php');
	exit();
}
else{
	$username	  = $_GET['username'];
	?>
	<h1 style= 'text-align:center;'>
	<?php
	if(user_exists($username) === true){
		$user_id	  = user_id_from_username($username);
		$profile_data = user_data($user_id, 'first_name', 'last_name', 'email', 'activities');
	?>

		
		
			<?php if( logged_in()===true && $user_data['username'] === $_GET['username']){
					echo 'Your Profile:';
				  } 
				  else{
				  	echo $profile_data['first_name'] . " " . $profile_data['last_name'] . '\'s Profile:';
				  }
				  	  
				 } else{
							echo 'Sorry, that user doesn\'t exist';
							exit();
						}?>
			
		</h1>
			<p style = 'text-align:center;'>
				  Activities: <?php echo $profile_data['activities'];?>
										
			</p>
			
	</body>


<?php 
}

?>
</html>