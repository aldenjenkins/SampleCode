<?php
include 'core/init.php'; 
protect_page();




if(empty($_POST) === false){
	$required_fields = array('first_name', 'email');

	foreach($_POST as $key=>$value){
		if(empty($value) && in_array($key, $required_fields) === true){
			$errors[] = 'Fields marked with an asterisk are required';
			break 1;
		}
	
	}

	if(empty($errors)===true){
		if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false){
			$errors[] = 'A valid email is required';
		} if(email_exists($_POST['email']) === true && $user_data['email'] !== $_POST['email']){
			$errors[] = 'Sorry, the email \'' . $_POST['email'] . '\' is already in use';
		}
		
	}

	iF(empty($_POST) === false && empty($errors) === true){
		$update_data = array(
				'first_name' 	=> $_POST['first_name'],
				'last_name' 	=> $_POST['last_name'],
				'email'			=> $_POST['email'],
				'activities' 	=> $_POST['activities']
		);
	
			
		update_user($update_data);
		header('Location: settings.php?success');
		exit();
			
	}
}
?>

	




<head>

<link rel="icon" type="image/x-icon" href="images/patriot.jpeg">
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Change Settings</title>
<link rel="stylesheet" href="css/settingsstyle.css">
<!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>

<body>
	<div class="login-help">
		<?php if(isset($_GET['success']) && empty($_GET['success'])){
			echo 'Your Settings have been Updated!';
			include 'includes/widgets/returntohome.php';
			
	}else{
		if (empty($errors) === false){
			echo output_errors($errors);
	}
	?>
    </div>
<section class="container">
<div class="login">
<h1>Change Profile Settings:</h1>
<form method="post" action="">

	<p>First Name:<input type="text" name="first_name" value="<?php echo $user_data['first_name'];?>" ></p>
	<p>Last Name:<input type="text" name="last_name" value="<?php echo  $user_data['last_name'];?>"></p>
	<p>Email:<input type="text" name="email" value="<?php echo $user_data['email'];?>"></p>
	<p>Activities:<textarea type="text" name="activities"  maxlength="1024" style="width:280 ;height: 128px;"><?php echo $user_data['activities'];?></textarea></p>
	
	
<p class="submit"><input type="submit"  value="Update"></p>
</form>

</div>

	<div class="login-help">
		<p><a href="index.php">Click Here</a> to return to the Home Page</p>
    </div>
  </section>

</body>

<?php 
	}?>