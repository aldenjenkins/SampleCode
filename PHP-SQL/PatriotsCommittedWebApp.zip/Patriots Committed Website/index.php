<?php 
include 'core/init.php';
?>
<!doctype html>
<?php 
include 'includes/head.php';
?>
 	<script type="text/javascript" src="js/modernizr.custom.86080.js"></script> 
	<link rel="stylesheet" type="text/css" href="css/style.css">
    <body id="page">
        <ul class="cb-slideshow">
            <li><span>Image 01</span><div><h3>Patriots Committed</h3></div></li>
            <li><span>Image 02</span><div><h3>Excellence</h3></div></li>
            <li><span>Image 03</span><div><h3>Teamwork</h3></div></li>
            <li><span>Image 04</span><div><h3>Leadership</h3></div></li>
            <li><span>Image 05</span><div><h3>Decision Making</h3></div></li>
            <li><span>Image 06</span><div><h3>Commitment</h3></div></li>
        </ul>
    </body>
	
	 <body>
		<?php include 'includes/userheader.php';?>
		<?php include 'includes/header.php';?>
		<?php include 'includes/nav.php';?>
		<?php if(!logged_in()===true){
				 include 'includes/loginnav.php';
			}
			?>
		<?php include 'includes/marquee.php';?>
		
		<div class="welcome">
		<h3>Welcome! </h3>
		</div>
		
		<?php if(logged_in()===true){
			include 'includes/widgets/loggedin.php';
		}
			else{
				include 'includes/widgets/user_count.php';	
			}
		?>	
		<article>
			<p>Welcome to the Patriots Committed website! Patriots Committed is a student-run organization dedicated to promoting healthy lifestyle choices for all Portsmouth residents. Here you can learn more about the lifestyle, what we're all about, and who our most proudly Committed Patriots are!	
			</p>
		</article>
		<div class= "aside">
			<article class="links">
				<h2 class="links">Useful Links:</h2>
			<ul>
				<li><a href="Portsmouth Times Article.docx"> Portsmouth Times Article</a></li>
			<br>
				<li>follow us on: <a href="http://www.twitter.com/pcommitted"> Twitter</a></li>
			<br>
				<li>and <a href="http://www.instagram.com/patriots_committed">Instagram</a></li>
			</ul>
			</article>
		</div>
		<div class="image" style="width:480px;" >
			<a class="twitter-timeline" style = " box-shadow: 0px 0px 50px 10px white;" href="https://twitter.com/PCommitted" data-widget-id="590541992096092160">Tweets by @PCommitted</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>		
		</div>
		<footer>
		<p>*Hosting donated by friends of the Portsmouth Prevention Coalition*</p>
		</footer>
	</body>
	</html>
	
