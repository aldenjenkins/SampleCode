<?php 
include 'core/init.php';
?>
<!doctype html>
<head>
	<link rel="stylesheet" type="text/css" href="protectedstyle.css">
	<link rel="icon" type="image/x-icon" href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/images/patriot.jpeg">
	<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css' href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/css/style.css">
</head>
	

	
	 <body>

		
		<?php include 'includes/userheader.php';?>
		
		<?php include 'includes/header.php';?>
		<?php include 'includes/nav.php';?>
		<?php if(!logged_in()===true){
				 include 'includes/loginnav.php';
			}
			?>
		<?php include 'includes/marquee.php';?>


	<body>
		<h1 style= 'text-align:center;'>
			Sorry, You Need to be logged in to view this page!
		</h1>
	</body>
</html>