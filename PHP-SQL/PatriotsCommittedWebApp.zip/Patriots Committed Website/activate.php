<?php
include 'core/init.php';
logged_in_redirect ();

if (isset ( $_GET ['success'] ) === true && empty ( $_GET ['success'] ) === true) {
	?>
<div class="login-help">
	<h2>Thanks, We've Activated your account...</h2>
	<p>You're Free to log in!</p>
	
	<?php
	
include 'includes/widgets/returntohome.php';
	?>
	</div>
<?php
} else if (isset ( $_GET ['email'], $_GET ['email_code'] ) === true) {
	
	$email = trim ( $_GET ['email'] );
	$email_code = trim ( $_GET ['email_code'] );
	
	if (email_exists ( $email ) === false) {
		$errors [] = 'Oops, something went wrong, and we couldn\'t find that email address! Are you sure it exists?';
	} else if (activate ( $email, $email_code ) === false) {
		$errors [] = 'We had problems activating your account';
	}
	
	?>
<div class="login-help">
	<?php
	if (empty ( $errors ) === false) {
		?>
			<h2>Oops.....</h2> 
		<?php
		echo output_errors ( $errors );
		include 'includes/widgets/returntohome.php';
		?>
			</div>
<?php
	} else {
		header ( 'Location: activate.php?success' );
		exit ();
	}
} else {
	header ( 'Location: index.php' );
	exit ();
}

?>
<!doctype html>
<head>
<link rel="stylesheet" type="text/css" href="css/registerstyle.css">
</head>

<body>


</body>
</html>