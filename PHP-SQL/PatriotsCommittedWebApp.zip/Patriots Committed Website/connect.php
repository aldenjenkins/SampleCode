<?php
$connect_error = 'Sorry, we\'re experiencing maintenance at the moment, please check back soon!';
mysql_connect ( ' ', ' ', ' ' ) or die ( $connect_error );
mysql_select_db ( 'lr' ) or die($connect_error);
?>