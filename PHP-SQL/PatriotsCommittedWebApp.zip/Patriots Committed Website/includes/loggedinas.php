<ul class="userheader">
<li class="liloggedinas"><style>li.loggedinas{color:white;}</style>Logged in as: <?php echo $user_data['first_name'];?>
<a class ="logout" href ="logout.php">Logout</a></li>
</ul>