
        <header>

	<img src="images/lake_placid.png">
	
</header>

