<head>
	<title>Patriots Committed</title>

	<link rel="icon" type="image/x-icon" href="images/patriot.png">
	<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css' href="css/style.css">
</head>