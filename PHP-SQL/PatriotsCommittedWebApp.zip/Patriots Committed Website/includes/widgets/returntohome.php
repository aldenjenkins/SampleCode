<p><a href="index.php">Click Here</a> to Return to the Home Page!</p>
