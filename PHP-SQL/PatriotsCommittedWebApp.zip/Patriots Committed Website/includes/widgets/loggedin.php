<div class= "aside">
	<article class="login">
			<h2 class="links">User Control Panel:</h2>
			<ul>
				<li><a href="profile.php?username=<?php echo $user_data['username'];?>">Profile</a></li>
			<br>
				<li><a href="changepassword.php">Change Password</a></li>
			<br>
				<li><a href="settings.php">Settings</a></li>
			</ul>
	</article>
</div>