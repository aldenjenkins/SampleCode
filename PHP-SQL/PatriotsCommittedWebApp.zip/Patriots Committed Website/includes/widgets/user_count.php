<div class="aside">
	<article class="login">
		<h2 class="links">Users</h2>
		<ul>
		<?php 
		$user_count = user_count();
		$suffix = ($user_count !=1) ? 's' : '';
		?>
			<li>We currently have <?php echo $user_count;?> registered user<?php echo $suffix;?></li>
			<br>
			<li><a href="register.php">Register!</a>
		</ul>
	</article>
</div>