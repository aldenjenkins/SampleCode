<nav class="login">
<ul>
<li><a class ="loginregister" href ="register.php">Register!</a></li>
<li><a class ="loginregister" href ="loginpage.php">Login</a></li>


</ul>
	
</nav>