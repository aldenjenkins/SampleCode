<html>
<nav class="controlpanel">


<?php if(logged_in()===true){	
	include 'includes/loggedinas.php';
}
	else{
	include 'includes/notloggedin.php';
}
?>


	
</nav>