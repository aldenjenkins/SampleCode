<nav class="normal">
			<ul>
				<li><a href ="index.php">Home</a></li>
				<li><a href ="info.php">Information</a>
					<ul>
						<li><a href ="contactus.php">Contact Us!</a></li>
					
					</ul>
				
				</li>
				<li><a href ="lifestyle.php">Lifestyle</a></li>
				
			</ul>
			
		</nav>