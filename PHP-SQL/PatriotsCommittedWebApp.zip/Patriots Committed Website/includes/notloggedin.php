<ul class="notloggedin">
<li class = "notloggedin">Not Logged In</li>
</ul>