<div class="global-msg homepage"><table id="sc-pageitem-7" cellpadding="0" cellspacing="0" width="1000px">
<tr>
<td valign="top"><div class="sc-layout-12 fontsize2"><span class="css-editor-pageitem-text "><marquee behavior="scroll" direction="left">
<strong>
<font size=+1  color= "white" "><span>Patriots Committed will be sponsoring a Pasta Dinner on April 12th at St. Barnabas Church from 6PM to 8PM</span></font>

</strong>
</marquee></span></div>