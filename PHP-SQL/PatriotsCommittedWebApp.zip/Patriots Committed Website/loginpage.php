<?php 
include 'core/init.php';
logged_in_redirect();
include 'includes/loginpagecontent.php';
?>