<?php
return mysqli_query ( (mysqli_connect ( 'localhost', 'root', 'mysql' , 'lr')) , "SELECT COUNT (`user_id`) FROM `users` WHERE `active` = 1" );
?>