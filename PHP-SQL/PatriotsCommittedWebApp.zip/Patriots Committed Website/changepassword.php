<?php
include 'core/init.php';
 protect_page();
if (empty ( $_POST ) === false) {
	$required_fields = array (
			'current_password',
			'password',
			'password_again' 
	);
	
	foreach ( $_POST as $key => $value ) {
		if (empty ( $value ) && in_array ( $key, $required_fields ) === true) {
			$errors [] = 'Fields marked with an asterisk are required';
			break 1;
		}
	}
	
	if ((md5 ( $_POST ['current_password'] )) === $user_data ['password']) {
		
		if (trim ( $_POST ['password'] ) !== trim ( $_POST ['password_again'] )) {
			$errors [] = 'Your new passwords do not match';
		} else if (strlen ( $_POST ['password'] ) < 6) {
			$errors [] = 'Your Password must be atleast 6 characters Long';
		} else if (md5 ( $_POST ['password'] ) === $user_data ['password']) {
			$errors [] = 'You must Choose a New Password';
		}
	} else {
		$errors [] = 'You\'re Current Password is incorrect';
	}
}

if (isset ( $_GET ['success'] ) && empty ( $_GET ['success'] )) {
}
if (empty ( $_POST ) === false && empty ( $errors ) === true) {
	
	change_password ( $session_user_id, $_POST ['password'] );
	header ( 'Location: changepassword.php?success' );
}

include 'includes/changepasswordcontent.php';
?>

