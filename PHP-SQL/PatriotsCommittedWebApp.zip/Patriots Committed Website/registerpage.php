<?php 
include 'core/init.php';
include 'includes/registercontent.php';
?>