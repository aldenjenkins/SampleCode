<?php
include 'core/init.php';
protect_page ();
?>
<!doctype html>
<head>
<title>Contact Us</title>
<link rel="stylesheet" type="text/css" href="css/contactstyle.css">
<link rel="icon" type="image/x-icon"
	href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/images/patriot.jpeg">
<link href='http://fonts.googleapis.com/css?family=Droid+Serif'
	rel='stylesheet' type='text/css'
	href="C:/Users/Alden/Documents/web design/Patriots Committed with PHP/lr/css/style.css">
</head>



<body>

		
		<?php include 'includes/userheader.php';?>
		
		<?php include 'includes/header.php';?>
		<?php include 'includes/nav.php';?>
		<?php
		
if (! logged_in () === true) {
			include 'includes/loginnav.php';
		}
		?>
		<?php include 'includes/marquee.php';?>


	
<body>
	<h1 style='text-align: center;'>This Page is currently Under Construction!</h1>
		
<form method="post" action="" style='margin-left: auto;
    margin-right: auto; display:inline-block;'>

	
	<p>Tell us your suggestions!
		<br>
		<textarea type="text" name="suggestions"  maxlength="1024" style="width:280 ;height: 128px;"><?php echo $user_data['activities'];?></textarea>
	</p>
	
	
<p class="submit"><input type="submit"  value="Submit Suggestions!"></p>
</form>

</body>
</html>