"""
    Author: Alden Jenkins
    Title: Airline Data Analyzer
    Date: 5/2/16
    
    
    Purpose: Given a text file with flight data, provide the user with
             various information regarding the data.
    
"""

def getData():
    
    airlines        = []
    flightNumbers   = []
    dTimes          = []
    aTimes          = []
    prices          = []
    question        = "Enter a name of a file to read the airlines from: "
    errorMsg        = "Please enter a correct file!"
    
    # Make sure that the user selects an existing file for the program.
    found = False
    while not found:
        try:
            # If the user does not enter a valid file, this line will throw an IOError
            inFile  = open(input(question), 'r')
            found   = True
            print("Loading data into the program....\n")
        except IOError:
            print(errorMsg)
            
    # Gets each section of data for each line in the file and adds them to parallel lists 
    for line in inFile:
        # Sets these variables to the values in each line split by ","
        airline, flightNumber, dTime, aTime, price = line.strip().split(",")
        airlines        += [airline]
        flightNumbers   += [flightNumber]
        dTimes          += [dTime]
        aTimes          += [aTime]
        prices          += [price]
    inFile.close()
    print("Done!\n")
    
    # Returns the lists of data
    return airlines, flightNumbers, dTimes, aTimes, prices


# Gets selection from the query
def query():
    
    selection = input("Please choose one of the following options:\n"                \
                      "1 -- Find all flights on a Particular Airline\n"              \
                      "2 -- Find the cheapest flight\n"                              \
                      "3 -- Find all flights less than the specified price\n"        \
                      "4 -- Find the shortest flight\n"                              \
                      "5 -- Find all flights that depart within a specified range\n" \
                      "6 -- Find the average price for a specified airline\n"        \
                      "7 -- Sort flights by price or duration\n"                     \
                      "8 -- Quit\n"                                                  \
                      "Choice ==> "                                                  )
    
    # Returns selection String
    return selection


# Creates the basic message template
def createMessage():
    
    message = []
    message.append("The flights that meet your criteria are:\n"          \
                   "AIRLINE\tFLT#\tDEPT\tARR\tPRICE\n"                   \
                   "--------------------------------------------------\n")
    
    # Returns the basic message template
    return message


# Finds flights on the particular airline
def getAirlineFlights(lists):
    
    errorMsg = "Invalid input -- try again"
    # Gets specific airline
    correctAirline = False
    while correctAirline == False:
        try:
            airline         = lists[0][lists[0].index(input("Enter an airline: "))]
            correctAirline  = True
        except ValueError:
            print(errorMsg)
    
    # Gets the indexes of flights in the specific airline.
    airlineIndexes = []
    for i in range(len(lists[1])):
        if lists[0][i] == airline:
            airlineIndexes.append(i)
          
    # Create the message.
    message = createMessage()
    for i in range(len(airlineIndexes)):
        message.append("%s\t%s\t%s\t%s\t%s\n" % (airline,\
                                                 lists[1][airlineIndexes[i]],\
                                                 lists[2][airlineIndexes[i]],\
                                                 lists[3][airlineIndexes[i]],\
                                                 lists[4][airlineIndexes[i]]))
        
    # Returns the message of flight data for each flight in the airline.
    return "".join(message)


# Print the cheapest flight and all of its data.
def getCheapest(lists):
    
    cheapest        = 99999
    cheapestIndex   = 0
    
    # Compares all prices in the price list to find the cheapest.
    for i in range(len(lists[4])):
        
        # Strip each price in the prices list and compare it to the current cheapest price
        price = int(lists[4][i].strip("$"))
        
        # Finds the cheapest flight
        if price < cheapest:
            cheapest        = price
            cheapestIndex   = i
    
    # Returns the cheapest flight's airline, flight number, and price
    return "The cheapest flights is %s %s at %s\n" % (lists[0][cheapestIndex],\
                                                      lists[1][cheapestIndex],\
                                                      lists[4][cheapestIndex] )
    

# Print flights cheaper than threshold
def getFlightsBelowThreshold(lists):
    
    numCheaper  = 0
    message     = createMessage()
    errorMsg    = "Please enter a valid number. E.g. 300\n"

    # Gets a price threshold
    found = False
    while not found:
        try:
            threshold = float(input("Enter your maximum price: "))
            found = True
        except ValueError:
            print(errorMsg)
    
    # If the price is less than the threshold, 
    # add the items in the parallel lists to the message
    for i in range(len(lists[4])):
        item = int(lists[4][i].strip("$"))
        if item < threshold:
            numCheaper += 1
            message.append("%s\t%s\t%s\t%s\t%s\n" % (lists[0][i], \
                                                     lists[1][i], \
                                                     lists[2][i], \
                                                     lists[3][i], \
                                                     lists[4][i]) )
    
    # Returns the amount of flights cheaper than the threshold
    if numCheaper > 0:
        return "".join(message)
    else:
        return "\nNo flights meet your criteria\n"


# Gets the shortest time in the list of times.
def getShortestTime(lists):

    shortestTime            = 999999
    shortestIndex           = 0
    
    for i in range(len(lists[3])):
        # Get Departure minutes.
        hDepart, mDepart    = lists[2][i].split(":")
        numMinutesDeparture = int(mDepart) + (int(hDepart) * 60)
        # Get Arrival minutes.
        hArrival, mArrival  = lists[3][i].split(":")
        numMinutesArrival   = int(mArrival) + (int(hArrival) * 60)
        # Calculate total minutes.
        totalMinutes        = numMinutesArrival - numMinutesDeparture
        # Find the shortest time.
        if totalMinutes < shortestTime:
            shortestTime    = totalMinutes
            shortestIndex   = i
            
    # Returns the message of the shortest flight and 
    # the other values of the flight's data in the parallel lists.
    return "\nThe shortest flight is %s %s at %s minutes\n" % (lists[0][shortestIndex], \
                                                               lists[1][shortestIndex], \
                                                               shortestTime)


# Print flights departing within the specified time range.
def getFlightsInRange(lists):
    
    message                 = createMessage()
    numFlightsInTimeRange   = 0
    correctTime             = False
    errorMsg                = "Enter a correct time. format: xx:xx\n"
    
    # Gets the time range from the user.
    while not correctTime:
        try:
            # Get start time and convert to minutes.
            start           = input("Enter a lower threshold departure time, e.g. 12:00 " )
            # Splitting by ":" will throw the value error if the format is not correct, asking the user to try again
            hStart, mStart  = start.split(":")
            totalStart      = ( (int(hStart) * 60) + int(mStart) )
            # Get end time and convert to minutes.
            end             = input("Enter the upper threshold departure time, e.g. 18:30 " )
            hEnd, mEnd      = end.split(":")
            totalEnd        = ( (int(hEnd) * 60) + int(mEnd) )
            correctTime     = True
        # If the times do not contain ":", make the user retry.
        except ValueError:
            print(errorMsg)
            
    # Get total minutes for both arrival and departure times for each flight in the file.        
    for i in range(len(lists[2])):
        # Get Departure minutes.
        h_iStart, m_iStart  = lists[2][i].split(":")
        total_iStart        = ( int(h_iStart) * 60 ) + int(m_iStart)
        # Get Arrival minutes.
        h_iEnd, m_iEnd      = lists[2][i].split(":")
        total_iEnd          = ( int(h_iEnd) * 60 ) + int(m_iEnd)
        # If the flight's times are within the bounds, add the flight's data to the message
        if totalStart <= total_iStart and totalEnd >= total_iEnd:
            numFlightsInTimeRange += 1
            message.append("%s\t%s\t%s\t%s\t%s\n" % (lists[0][i], \
                                                     lists[1][i], \
                                                     lists[2][i], \
                                                     lists[3][i], \
                                                     lists[4][i]) )
            
    # Returns the flights and all of their data which depart within the specific time range
    # or none if no flights meet the criteria.
    if numFlightsInTimeRange > 0:
        return "".join(message)
    else:
        return "\nNo flights meet your criteria\n"
    
    
# Prints the average price for a specific airline.  
def getAveragePrice(lists):
    
    totalPrice      = 0
    numPrices       = 0
    correctAirline  = False
    errorMsg        = "Invalid input -- try again"
    
    # Gets specific airline.
    while not correctAirline:
        try:
            airline         = lists[0][lists[0].index(input("Enter an airline: "))]
            correctAirline  = True
        except ValueError:
            print(errorMsg)
            
    # Add all of the prices of the specific airline
    for i in range(len(lists[4])):
        if lists[0][i] == airline:
            totalPrice += int(lists[4][i].strip("$"))
            numPrices  += 1
            
    # Rounds the average price to two decimal places
    avgPrice = "$" + str( round((totalPrice / numPrices), 2) )
            
    # Returns the average prices for that airline
    return ("The average price is %s\n" % avgPrice)
   
   
# Print a list of flights sorted by either price or duration
def getSortedFlights(lists):
    
    selected    = False
    selection   = ""
    message     = createMessage()
    errorMsg    = "Please Enter Either 'P' for Price or 'D' for Duration.\n"
    question    = "Would you Like to sort by Price (\"P\") or Duration (\"D\")? "
    price       = []
    time        = []
    indexes     = []
    
    # Makes sure the user selects either "P" or "D" using a nand gate
    while not selected:
            selection = input(question)
            if (selection != "P") and (selection != "D"):
                print(errorMsg)
            else:
                selected = True
    
    # FOR INSTRUCTOR: Even though all of the flights are already sorted by price in the file... 
    # I've added the ability to sort the flights by decreasing price regardless.
    if selection == "P":
    # Execute code for sorting by Price
        # Prices has a list of prices as well as the corresponding index of the flight 
        prices      = [price, indexes]
        placeholder = 0
        
        # Fill the Lists with prices and indexes
        for i in range(len(lists[4])):
            prices[0] += [int(lists[4][i].strip("$"))]
            prices[1] += [i]
        
        # Sort the prices and parallel indexes
        for i in range(len(prices[0])):
            for j in range(i, len(prices[0])-1):
                if prices[0][i] < prices[0][j+1]:
                    # Swap the prices
                    placeholder    = prices[0][j+1]
                    prices[0][j+1] = prices[0][i]
                    prices[0][i]   = placeholder
                    # Swap the index
                    placeholder    = prices[1][j+1]
                    prices[1][j+1] = prices[1][i]
                    prices[1][i]   = placeholder
        
        # Finalize the Message
        for i in range(len(prices[1])): 
            message.append("%s\t%s\t%s\t%s\t%s\n" % (lists[0][prices[1][i]], \
                                                     lists[1][prices[1][i]], \
                                                     lists[2][prices[1][i]], \
                                                     lists[3][prices[1][i]], \
                                                     lists[4][prices[1][i]]) )
            
       
    else:
    # Execute code for Sorting by Duration     
        # Times is a 2D list of all of the times and their indexes from the file
        times       = [time, indexes]
        placeholder = 0
        
        # Iterate through the list of departure times 
        # (choosing len of departure vs length of arrival times is arbitrary)
        # And calculate each duration and add itself and its index to the 2D list 'times'
        for i in range(len(lists[2])):
            # Get Departure minutes.
            h_Start, m_Start   = lists[2][i].split(":")
            total_Start        = ( int(h_Start) * 60 ) + int(m_Start)
            # Get Arrival minutes.
            h_End, m_End       = lists[3][i].split(":")
            total_End          = ( int(h_End) * 60 ) + int(m_End)
            # Calculate total minutes
            totalMinutes       = total_End - total_Start 
            # Add the duration and index to the 2D list
            times[0] += [totalMinutes]
            times[1] += [i]
    
        # Sort the prices and parallel indexes
        for i in range(len(times[0])):
            for j in range(i, len(times[0])-1):
                if times[0][j+1] < times[0][i]:
                    # Swap the prices
                    placeholder   = times[0][i]
                    times[0][i]   = times[0][j+1]
                    times[0][j+1] = placeholder
                    # Swap the index
                    placeholder   = times[1][i]
                    times[1][i]   = times[1][j+1]
                    times[1][j+1] = placeholder
        
        # Finalize the Message
        for i in range(len(times[1])): 
            message.append("%s\t%s\t%s\t%s\t%s\t" \
                           "With a duration of: %s minutes \n" % (lists[0][times[1][i]], \
                                                                  lists[1][times[1][i]], \
                                                                  lists[2][times[1][i]], \
                                                                  lists[3][times[1][i]], \
                                                                  lists[4][times[1][i]], \
                                                                  times[0][i]          ) )
            
    return "".join(message)

# The main functions implements the pseudocode by using the functions defined above
def main():
    
    # Creates lists from getData and then adds those lists to the list "lists" as a 2D list
    airlines,       \
    flightNumbers,  \
    dTimes,         \
    aTimes,         \
    prices          = getData()
    lists           = [airlines,
                       flightNumbers, 
                       dTimes, 
                       aTimes, 
                       prices]
    errorMsg        = ("Please enter one of the numbers presented\n"\
                       "-----------------------------------------\n")
    # I use functional programming to get an input from the user based on the query
    # and then executes the corresponding function based on the assigned correspondence in queryFunctions
    while True:
        selection = query()
        if selection == "8":
            break
        queryFunctions = {'1':getAirlineFlights,        
                          '2':getCheapest,              
                          '3':getFlightsBelowThreshold, 
                          '4':getShortestTime,          
                          '5':getFlightsInRange,        
                          '6':getAveragePrice,          
                          '7':getSortedFlights          }
        try:
            print ( queryFunctions.get(selection)(lists) )
        except TypeError:
            print(errorMsg)
        
    print("Thanks for using my program!")
    

main()